﻿public enum TrackerPreset
{
    Standard,
    Vicon,
}
